#include <iostream>


#include "test_scurt.h"
#include "test_extins.h"

int main() {
    //test_extra();
    testAll();
    testAllExtins();
    std::cout << "Finished LP Tests!" << std::endl;
}
