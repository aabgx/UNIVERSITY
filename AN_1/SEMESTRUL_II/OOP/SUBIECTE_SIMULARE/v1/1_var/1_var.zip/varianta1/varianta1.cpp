#include "varianta1.h"

varianta1::varianta1(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
