/********************************************************************************
** Form generated from reading UI file 'varianta1.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_VARIANTA1_H
#define UI_VARIANTA1_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_varianta1Class
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *varianta1Class)
    {
        if (varianta1Class->objectName().isEmpty())
            varianta1Class->setObjectName(QString::fromUtf8("varianta1Class"));
        varianta1Class->resize(600, 400);
        menuBar = new QMenuBar(varianta1Class);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        varianta1Class->setMenuBar(menuBar);
        mainToolBar = new QToolBar(varianta1Class);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        varianta1Class->addToolBar(mainToolBar);
        centralWidget = new QWidget(varianta1Class);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        varianta1Class->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(varianta1Class);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        varianta1Class->setStatusBar(statusBar);

        retranslateUi(varianta1Class);

        QMetaObject::connectSlotsByName(varianta1Class);
    } // setupUi

    void retranslateUi(QMainWindow *varianta1Class)
    {
        varianta1Class->setWindowTitle(QCoreApplication::translate("varianta1Class", "varianta1", nullptr));
    } // retranslateUi

};

namespace Ui {
    class varianta1Class: public Ui_varianta1Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_VARIANTA1_H
