#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_varianta1.h"

class varianta1 : public QMainWindow
{
    Q_OBJECT

public:
    varianta1(QWidget *parent = Q_NULLPTR);

private:
    Ui::varianta1Class ui;
};
