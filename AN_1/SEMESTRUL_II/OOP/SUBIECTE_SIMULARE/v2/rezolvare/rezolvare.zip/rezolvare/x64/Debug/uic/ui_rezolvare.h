/********************************************************************************
** Form generated from reading UI file 'rezolvare.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_REZOLVARE_H
#define UI_REZOLVARE_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_rezolvareClass
{
public:
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QWidget *centralWidget;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *rezolvareClass)
    {
        if (rezolvareClass->objectName().isEmpty())
            rezolvareClass->setObjectName(QString::fromUtf8("rezolvareClass"));
        rezolvareClass->resize(600, 400);
        menuBar = new QMenuBar(rezolvareClass);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        rezolvareClass->setMenuBar(menuBar);
        mainToolBar = new QToolBar(rezolvareClass);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        rezolvareClass->addToolBar(mainToolBar);
        centralWidget = new QWidget(rezolvareClass);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        rezolvareClass->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(rezolvareClass);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        rezolvareClass->setStatusBar(statusBar);

        retranslateUi(rezolvareClass);

        QMetaObject::connectSlotsByName(rezolvareClass);
    } // setupUi

    void retranslateUi(QMainWindow *rezolvareClass)
    {
        rezolvareClass->setWindowTitle(QCoreApplication::translate("rezolvareClass", "rezolvare", nullptr));
    } // retranslateUi

};

namespace Ui {
    class rezolvareClass: public Ui_rezolvareClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_REZOLVARE_H
