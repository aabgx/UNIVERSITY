#include "rezolvare.h"

rezolvare::rezolvare(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
