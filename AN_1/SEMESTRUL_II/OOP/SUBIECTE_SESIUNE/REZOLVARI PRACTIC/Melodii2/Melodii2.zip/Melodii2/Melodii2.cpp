#include "Melodii2.h"

Melodii2::Melodii2(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
