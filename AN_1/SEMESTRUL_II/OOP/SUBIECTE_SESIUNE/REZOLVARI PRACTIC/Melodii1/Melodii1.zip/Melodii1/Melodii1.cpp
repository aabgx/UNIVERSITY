#include "Melodii1.h"

Melodii1::Melodii1(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
