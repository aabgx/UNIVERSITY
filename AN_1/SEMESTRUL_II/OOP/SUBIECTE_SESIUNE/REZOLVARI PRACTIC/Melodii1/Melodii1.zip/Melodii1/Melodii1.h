#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_Melodii1.h"

class Melodii1 : public QMainWindow
{
    Q_OBJECT

public:
    Melodii1(QWidget *parent = Q_NULLPTR);

private:
    Ui::Melodii1Class ui;
};
