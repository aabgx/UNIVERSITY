#include "Produse.h"

Produse::Produse(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
